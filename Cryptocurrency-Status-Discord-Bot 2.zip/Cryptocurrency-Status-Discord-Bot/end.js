const axios = require('axios')
const Discord = require('discord.js')
const client = new Discord.Client()

const coinId = 'charactbit';
const guildId = '927104075697356810';
const botSerect= 'OTY0NTk1MzQyNTEzNDM4ODEw.Ylm7ag.WFYLq5UgJAQeqTz6nBqgC-3dUFY';



function getPrices() {


	// API for price data.
	axios.get(`https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=${coinId}`).then(res => {
		// If we got a valid response
		if(res.data && res.data[0].current_price && res.data[0].price_change_percentage_24h) {
			let currentPrice = res.data[0].current_price || 0 // Default to zero
			let priceChange = res.data[0].price_change_24h || 0 // Default to zero
			let priceChangePct = res.data[0].price_change_percentage_24h || 0 
			let symbol = res.data[0].symbol || '?' 
			client.user.setPresence({
				game: {
					// Example: "Watching -5,52% | BTC"
					name: `${priceChange.toFixed(2)} (${priceChangePct.toFixed(2)}%)`,
					type: 1 // Use activity type 3 which is "Watching"
				}
			})

			client.guilds.find(guild => guild.id === `${guildId}`).me.setNickname(`${symbol.toUpperCase()} $${(currentPrice).toLocaleString().replace(/,/g,',')}`)

			console.log('Updated price to', currentPrice)
		}
		else
			console.log('Could not load player count data for', process.env.COIN_ID)

	}).catch(err => console.log('Error at api.coingecko.com data:', err))
}

// Runs when client connects to Discord.
client.on('ready', () => {
	console.log('Logged in as', client.user.tag)

	getPrices() // Ping server once on startup
	// Ping the server and set the new status message every x minutes. (Minimum of 1 minute)
	setInterval(getPrices, Math.max(1, 1 || 1) * 60 * 1000)
})

// Login to Discord
client.login(`${botSerect}`)
